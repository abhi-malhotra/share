/********************************************************************/
/*                                                                  */
/*   comsubs.h - header file for comsubs.c                          */
/*                                                                  */
/********************************************************************/
void Log(const char *szFormat, ...);
int openLog(const char * fileName);
void closeLog();
char * skipBlanks(char *str);
char * findBlank(char *str);
void strupper(char *str);
void rtrim(char *str);
int reverseBytes4(int var);
void AsciiToEbcdic(unsigned char *dato, const unsigned char *dati, unsigned int pl);
void EbcdicToAscii(const unsigned char *dati, unsigned int pl, unsigned char *dato);
void AsciiToHex(unsigned char *dato, unsigned char *dati, unsigned int pl);
void HexToAscii(char *dati, int pl, char *dato);
char * removeQuotes(char *dati);
int64_t reverseBytes8(int64_t in);
void reverseBytes24(unsigned char *in, unsigned char *out);
void reverseBytes32(unsigned char *in, unsigned char *out);
int64_t my_ato64(const char * valueptr);
void editHexParm(const char * parmName, 
				 char * parm, 
				 char * valueptr, 
				 int maxsize);
int checkHexParm(const char * parmName,
				  const char * parmConst,
				  char * parm, 
				  char * valueptr, 
				  int foundit,
				  int maxsize);
void editCharParm(const char * parmName, 
				 char * parm, 
				 char * valueptr, 
				 int maxsize);
int checkCharParm(const char * parmName,
				  const char * parmConst,
				  char * parm, 
				  char * valueptr, 
				  int * foundParm,
				  int foundit,
				  int maxsize);
void editYNParm(const char * parmName, 
				int * parm, 
				char * valueptr);
int checkYNParm(const char * parmName,
				const char * parmConst,
				int * parm, 
				char * valueptr, 
				int * foundParm,
				int foundit);
int checkIntParm(const char * parmName,
				 const char * parmConst,
				 int * value, 
				 int * foundParm,
				 char * valueptr, 
				 int foundit);

int checkI64Parm(const char * parmName,
				 const char * parmConst,
				 int64_t * value, 
				 int * foundParm,
				 char * valueptr, 
				 int foundit);
