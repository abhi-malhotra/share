/********************************************************************/
/*                                                                  */
/*   qsubs.h - header file for qsubs.c                              */
/*                                                                  */
/********************************************************************/

void checkerror(const char *mqcalltype, MQLONG compcode, MQLONG reason, const char *resource);
void connect2QM(char * qmname, PMQHCONN qm, PMQLONG cc, PMQLONG reason);
void clientConnect2QM(char * qmname, PMQHCONN qm, int *maxMsgLen, PMQLONG cc, PMQLONG reason);
