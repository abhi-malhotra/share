/* parmline.h header file used in MQPut2 and MQPuts programs */

#ifndef _parmline_
#define _parmline_

/* includes for MQI */
#include <cmqc.h>

#define	MQMD_NO					0			/* ignore saved MQMDs in files */
#define MQMD_YES				1			/* use saved MQMDs if found at front of message */

#define	RFH_NO					0
#define RFH_V1					1
#define RFH_V2					2
#define RFH_XML					3
#define RFH_AUTO				4

#define TIMESTAMP_NO			0
#define TIMESTAMP_YES			1
#define TIMESTAMP_AUTO			2

#define TIMESTAMP_FORMAT_BIN	0
#define TIMESTAMP_FORMAT_HEX	1

#define MAX_RFH_DATA_LEN	64

/* maximum field lengths */
#define MAX_TOPIC_LEN		1024
#define MAX_SUBPOINT_LEN	1024
#define MAX_FILTER_LEN		1024
#define MAX_PUBTIME_LEN		32
#define MAX_JMS_DEST		256
#define MAX_JMS_REPLY		256
#define MAX_JMS_CORRELID	32
#define MAX_JMS_GROUPID		32
#define MAX_JMS_EXPIRE		32
#define MAX_JMS_DELMODE		16
#define MAX_JMS_SEQ			16
#define MAX_JMS_PRIORITY	16

/**************************************************************/
/*                                                            */
/* Parameter values from parameter file.                      */
/*                                                            */
/**************************************************************/

typedef struct {
	/* global error switch */
	int			err;

	/* verbose switch */
	int			verbose;

	/* total memory used               */
	int			memUsed;		

	/* Counters and statistics         */
	int			fileCount;				/* number of files read            */
	int			mesgCount;				/* number of messages found        */

	/* name of the parameters file */
	char		parmFilename[512];

	/* delimiter value, if specified */
	int			delimiterLen;
	char		delimiter[32];

	/* Universal parameters */
	int			persist;
	int			priority;
	int			batchsize;				/* number of messages in a unit of work */
	int			saveBatchSize;
	int			saveThinkTime;
	int			qdepth;
	int			qmax;
	int			sleeptime;
	int			tune;

	/* Queue names to write to - universal */
	char		qname[MQ_Q_NAME_LENGTH + 4];
	char		qmname[MQ_Q_MGR_NAME_LENGTH + 4];
	char		saveQname[MQ_Q_NAME_LENGTH + 4];
	char		saveQReply[MQ_Q_NAME_LENGTH + 4];
	char		saveQMname[MQ_Q_MGR_NAME_LENGTH + 4];
	char		remoteQM[MQ_Q_MGR_NAME_LENGTH + 4];

	/* MQMD parameters - per message */
	int			useMQMD;
	int			ignoreMQMD;
	int			newMsgId;
	int			codepage;
	int			encoding;
	int			expiry;
	int			msgtype;
	int			feedback;
	int			report;
	int			GetByCorrelId;			/* used by MQLatency */
	int			correlidSet;
	int			groupidSet;
	int			acctTokenSet;
	int			inGroup;
	int			lastGroup;
	int			fileAsGroup;
	int			formatSet;

	/* RFH parameters - per message */
	int			rfh;
	int			rfhlength;
	unsigned char	rfhdata[128 * 1024];

	/* MQMD parameters - per message */
	char		correlid[MQ_CORREL_ID_LENGTH + 4];
	char		groupid[MQ_GROUP_ID_LENGTH + 4];
	char		msgformat[MQ_FORMAT_LENGTH + 4];
	char		replyQ[MQ_Q_NAME_LENGTH + 4];
	char		replyQM[MQ_Q_MGR_NAME_LENGTH + 4];
	char		userId[MQ_USER_ID_LENGTH + 4];
	char		accountingToken[MQ_ACCOUNTING_TOKEN_LENGTH + 4];

	/* field to remember the current group id */
	char		saveGroupId[MQ_GROUP_ID_LENGTH + 4];

	/* think time after message is written (in milliseconds) */
	int			thinkTime;

	/* Report progress after this number of messages */
	int			reportEvery;

	/* Maximum time to wait for a reply message - default is 5 seconds */
	int			maxWaitTime;

	/* set time stamp */
	int			setTimeStamp;

	/* Indication that set context must be used on MQOpen */
	int			foundMQMD;				/* found at least one MQMD in file */

	/* write each message once, ignoring the count parameter */
	int			writeOnce;	

	/* switch to determine if reply queue should be purged before sending any messages */
	int			purgeQ;

	/* RFH fields */
	char		rfhdomain[MAX_RFH_DATA_LEN + 4];
	char		rfhset[MAX_RFH_DATA_LEN + 4];
	char		rfhtype[MAX_RFH_DATA_LEN + 4];
	char		rfhfmt[MAX_RFH_DATA_LEN + 4];
	char		rfhappgroup[MAX_RFH_DATA_LEN + 4];
	char		rfhformat[MAX_RFH_DATA_LEN + 4];
	char		rfh_PscReplyQ[MQ_Q_NAME_LENGTH + 4];
	char		rfh_PscReplyQM[MQ_Q_MGR_NAME_LENGTH + 4];
	char		rfh_topic1[MAX_TOPIC_LEN];
	char		rfh_topic2[MAX_TOPIC_LEN];
	char		rfh_topic3[MAX_TOPIC_LEN];
	char		rfh_topic4[MAX_TOPIC_LEN];
	char		rfh_subpoint[MAX_SUBPOINT_LEN];
	char		rfh_filter[MAX_FILTER_LEN];
	char		rfh_pubtime[MAX_PUBTIME_LEN];
	char		rfh_jms_dest[MAX_JMS_DEST];
	char		rfh_jms_reply[MAX_JMS_REPLY];
	char		rfh_jms_correlid[MAX_JMS_CORRELID];
	char		rfh_jms_groupid[MAX_JMS_GROUPID];
	char		rfh_jms_expire[MAX_JMS_EXPIRE];
	char		rfh_jms_delmode[MAX_JMS_DELMODE];
	char		rfh_jms_seq[MAX_JMS_SEQ];
	char		rfh_jms_priority[MAX_JMS_PRIORITY];

	int			rfhccsid;
	int			rfhencoding;
	int			nameValueCCSID;
	int			rfh_psc_seqno;
	int			rfh_psc_reqtype;
	int			rfh_jms_reqtype;
	int			rfh_psc_local;
	int			rfh_psc_newonly;
	int			rfh_psc_otheronly;
	int			rfh_psc_ondemand;
	int			rfh_psc_retainpub;
	int			rfh_psc_isretainpub;
	int			rfh_psc_correlid;
	int			rfh_psc_deregall;
	int			rfh_psc_infretain;
	int			rfh_psc_pers_type;

	/* pointers to various RFH areas */
	char *			rfh_usr;
	char *			rfh_jms;
	char *			rfh_mcd;
	char *			rfh_psc;
	char *			rfh_pscr;
	unsigned int	max_usr;
	unsigned int	max_jms;
	unsigned int	max_mcd;
	unsigned int	max_psc;
	unsigned int	max_pscr;

	/* counters and statistics */
	/* number of bytes written */
	int64_t		totcount;
	int64_t		saveTotcount;
	int64_t		msgwritten;
	int64_t		byteswritten;

	/* indicate already tried to handle 2068 error on MQINQ */
	int			reopenInq;

	/* total number of bytes read */
	int			totMsgLen;	

	/* number of messages read */
	int			msgsRead;

	/* message id from last message that was written */
	/* used for get by correl id */
	MQBYTE24	savedMsgId;
} putParms;

int processParmLine(char * ptr, putParms *parms);
int processFirstUsrLine(char * ptr, putParms *parms);
int processUsrLine(char * ptr, int foundit, putParms * parms);
void processArgs(int argc, char **argv, putParms *parms);
void initializeParms(putParms *parms);
void processOverrides(putParms *parms);

#endif	/* _parmline_ */


